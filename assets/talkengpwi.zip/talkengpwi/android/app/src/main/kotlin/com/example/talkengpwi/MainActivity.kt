package com.example.talkengpwi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
